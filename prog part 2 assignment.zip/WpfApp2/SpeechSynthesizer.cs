﻿
internal class SpeechSynthesizer
{
    internal void SpeakAsync(string text)
    {
        throw new NotImplementedException();
    }
}