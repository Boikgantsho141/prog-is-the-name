﻿using Microsoft.VisualBasic.ApplicationServices;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.ServiceProcess;
internal class Program
{
    private static void Speak(string text)
        {
            SpeechSynthesizer synth = new SpeechSynthesizer();

            synth.SpeakAsync(text);
        }
    }


namespace CyberSecurityChatbot
{
    public partial class MainWindow : Window
    {
        // ==============================
        // MEMORY VARIABLES
        // ==============================

        string userName = "";
        string favouriteTopic = "";

        // ==============================
        // RANDOM OBJECT
        // ==============================

        Random random = new Random();

        // ==============================
        // KEYWORD RESPONSES
        // ==============================

        Dictionary<string, List<string>> keywordResponses =
            new Dictionary<string, List<string>>()
        {
            {
                "password",
                new List<string>()
                {
                    "Use strong passwords with symbols and numbers.",
                    "Avoid using the same password for all accounts.",
                    "Enable two-factor authentication for extra security."
                }
            },

            {
                "privacy",
                new List<string>()
                {
                    "Review your social media privacy settings regularly.",
                    "Avoid sharing personal information publicly.",
                    "Use secure websites that start with HTTPS."
                }
            },

            {
                "scam",
                new List<string>()
                {
                    "Never click suspicious email links.",
                    "Verify unknown senders before responding.",
                    "Scammers often create urgency to trick users."
                }
            },

            {
                "phishing",
                new List<string>()
                {
                    "Do not open suspicious attachments.",
                    "Check email addresses carefully.",
                    "Phishing attacks often imitate trusted companies."
                }
            },

            {
                "virus",
                new List<string>()
                {
                    "Install antivirus software.",
                    "Keep your operating system updated.",
                    "Avoid downloading files from unknown websites."
                }
            }
        };
        private object greeting;

        // ==============================
        // DELEGATE
        // ==============================

        delegate string ResponseDelegate(string input);

        public MainWindow()
        {
            InitializeComponent();

            PlayGreeting();

            ShowBotMessage("Hello! Welcome to the Cybersecurity Awareness Chatbot.");
            ShowBotMessage("Please tell me your name.");
        }

        // ==============================
        // SEND BUTTON
        // ==============================

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string input = UserInput.Text.Trim();

                if (string.IsNullOrEmpty(input))
                {
                    MessageBox.Show("Please enter a message.");
                    return;
                }

                ShowUserMessage(input);

                ResponseDelegate response = GenerateResponse;

                string botReply = response(input);

                ShowBotMessage(botReply);

                UserInput.Clear();
            }
            catch (Exception ex)
            {
                ShowBotMessage("An error occurred: " + ex.Message);
            }
        }

        // ==============================
        // GENERATE RESPONSE
        // ==============================

        private string GenerateResponse(string input)
        {
            input = input.ToLower();

            // ==============================
            // STORE NAME
            // ==============================

            if (input.StartsWith("my name is"))
            {
                userName = input.Replace("my name is", "").Trim();

                return "Nice to meet you, " + userName + "!";
            }

            // ==============================
            // STORE FAVOURITE TOPIC
            // ==============================

            if (input.Contains("interested in"))
            {
                string[] words = input.Split(' ');

                favouriteTopic = words.Last();

                return "Great! I'll remember that you're interested in "
                    + favouriteTopic +
                    ". It's an important cybersecurity topic.";
            }

            // ==============================
            // MEMORY RECALL
            // ==============================

            if (input.Contains("what do you remember"))
            {
                return "Your name is " + userName +
                       " and you are interested in " +
                       favouriteTopic + ".";
            }

            // ==============================
            // SENTIMENT DETECTION
            // ==============================

            if (input.Contains("worried"))
            {
                return "It's understandable to feel worried about cybersecurity threats. " +
                       "Always avoid clicking suspicious links and verify websites carefully.";
            }

            if (input.Contains("frustrated"))
            {
                return "Cybersecurity can feel overwhelming sometimes, but learning small safety habits helps a lot.";
            }

            if (input.Contains("curious"))
            {
                return "Curiosity is great! Learning about cybersecurity helps you stay protected online.";
            }

            // ==============================
            // KEYWORD DETECTION
            // ==============================

            foreach (var keyword in keywordResponses)
            {
                if (input.Contains(keyword.Key))
                {
                    int index = random.Next(keyword.Value.Count);

                    string response = keyword.Value[index];

                    // PERSONALISED RESPONSE
                    if (!string.IsNullOrEmpty(favouriteTopic))
                    {
                        response += "\n\nSince you're interested in "
                                 + favouriteTopic +
                                 ", you should continue learning about online safety.";
                    }

                    return response;
                }
            }

            // ==============================
            // GREETINGS
            // ==============================

            if (input.Contains("hello") || input.Contains("hi"))
            {
                return "Hello " + userName + "! How can I help you today?";
            }

            // ==============================
            // DEFAULT RESPONSE
            // ==============================

            return "I'm not sure I understand. Can you try rephrasing?";
        }

        // ==============================
        // DISPLAY USER MESSAGE
        // ==============================

        private void ShowUserMessage(string message)
        {
            ChatDisplay.AppendText("YOU: " + message + "\n\n");
        }

        // ==============================
        // DISPLAY BOT MESSAGE
        // ==============================

        private void ShowBotMessage(string message)
        {
            ChatDisplay.AppendText("BOT: " + message + "\n\n");
        }

        // ==============================
        // VOICE GREETING
        // ==============================
        
        private void PlayGreeting()
        {
          
                 
            try
            {
                SoundPlayer player =
                    new SoundPlayer(@"C:\Users\Student\source\repos\WpfApp2");

                player.Play();
            }
            catch
            {
                MessageBox.Show("Voice greeting file not found.");
            }
        }
    }
}